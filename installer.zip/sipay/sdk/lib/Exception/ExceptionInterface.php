<?php

declare(strict_types=1);

namespace PWall\Exception;

interface ExceptionInterface
{
}
